#include <stdio.h>
#include <math.h>

int main()
{
	int hadi = 20; // study hours per week
	int abdullah = 20;
	int asim = 21;
	
	hadi = hadi * 4; // study hours per month
	abdullah = abdullah * 4;
	asim = asim * 4;  
		
	printf("Average hours for hadi => %d \n", hadi);		
	printf("Average hours for abdullah => %d \n", abdullah);
	printf("Average hours for asim => %d \n", asim);
	return 0;
}
